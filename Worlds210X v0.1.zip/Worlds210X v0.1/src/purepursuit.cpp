#include "main.h"
using namespace std;

//state variables for xdisp, ydisp, oreintation
float xdisp = 0;
float ydisp = 0;
float heading = 0;

float tL = 5;
float tR = 5;

float gearratio = 1;
float wheeldiameter = 3.25;

float cradius;
float ctheta;

//pi
float PI = 3.1415926535897932384626;
float encoderscalar = gearratio*wheeldiameter*PI;

float absdisp(float position[2])
{
    return fabs(sqrt(pow(xdisp - position[0], 2)+pow(ydisp - position[1], 2)));
}

void radius(float position[2])
{
    float xdist = xdisp - position[0]; float ydist = ydisp - position[1];
    float absdist = absdisp(position);
    // float hinitial = heading; float hfinal = 2*atan2(ydist, xdist)-hinitial;
    float theta = heading-(2*atan2(ydist, xdist)-heading); float sideangle = (180-theta)/2;
    radius = sin(sideangle)*absdist/sin(theta); ctheta = theta;
}

float getgyro() {
    return looparound((LGyro.get_heading()+RGyro.get_heading())/2)*PI/180;
}

void curveto(float waypoint[2], int voltage) {
    float initialgyro = getgyro();

    //while loop
    while (absdisp(waypoint) > 1) {
        radius(waypoint);

        float arcL = (cradius+tL)*ctheta; float arcR = (cradius-tR)*ctheta;
        float cscale = voltage/max(arcL, arcR);

        //setting motors to curve
        setDriveMotors(cscale*arcL, cscale*arcR, false);

        //noting current encoder values with tracking motors
        float rinitial = rbbmotor.get_position(); float linitial = lbbmotor.get_position();

        pros::delay(10);
        //calculating displacements, convert rfinal and lfinal to inches
        float rfinal = (rbbmotor.get_position()-rinitial)/encoderscalar;
        float lfinal = (lbbmotor.get_position()-linitial)/encoderscalar;

        //calculating actual travelled circle
        float ftheta = getgyro() - initialgyro; float angO = (getgyro() + initialgyro)/2;
        float secant = sin(ftheta)*((rfinal+lfinal)/(2*ftheta))/sin((180-ftheta)/2);

        //updating displacemnet values
        xdisp += cos(angO)*secant;
        ydisp += sin(angO)*secant;

        initialgyro = getgyro();
        heading = getgyro();
    }
}