#include "main.h"

//controller declarations
pros::Controller master(pros::E_CONTROLLER_MASTER);

//porting declarations
int plttmotor = 17;
int pltbmotor = 16;
int plbtmotor = 13;
int plbbmotor = 10;

int prttmotor = 7;
int prtbmotor = 6;
int prbtmotor = 4;
int prbbmotor = 1;
//motor declarations
//pros::Motor (motorname)(port#, motor-cartridge, reversedmotor, motorencoders)
pros::Motor lttmotor(plttmotor, pros::E_MOTOR_GEARSET_36, true, pros::E_MOTOR_ENCODER_COUNTS);
pros::Motor ltbmotor(pltbmotor, pros::E_MOTOR_GEARSET_18, true, pros::E_MOTOR_ENCODER_COUNTS);
pros::Motor lbtmotor(plbtmotor, pros::E_MOTOR_GEARSET_18, true, pros::E_MOTOR_ENCODER_COUNTS);
pros::Motor lbbmotor(plbbmotor, pros::E_MOTOR_GEARSET_18, false, pros::E_MOTOR_ENCODER_COUNTS);

pros::Motor rttmotor(prttmotor, pros::E_MOTOR_GEARSET_36, false, pros::E_MOTOR_ENCODER_COUNTS);
pros::Motor rtbmotor(prtbmotor, pros::E_MOTOR_GEARSET_18, false, pros::E_MOTOR_ENCODER_COUNTS);
pros::Motor rbtmotor(prbtmotor, pros::E_MOTOR_GEARSET_18, false, pros::E_MOTOR_ENCODER_COUNTS);
pros::Motor rbbmotor(prbbmotor, pros::E_MOTOR_GEARSET_18, true, pros::E_MOTOR_ENCODER_COUNTS);

//piston declarations
pros::ADIDigitalOut tpiston('A');
pros::ADIDigitalOut ptopiston('B');

pros::ADIDigitalOut clawpiston('C');
pros::ADIDigitalOut retractpiston('D');


//encoders, gyros, inertials, etc

//std::cout << "gyro init ran" << std::endl;
pros::IMU LGyro(20); 
pros::IMU RGyro(11); 
