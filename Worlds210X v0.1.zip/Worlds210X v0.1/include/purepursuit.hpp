#include "main.h"

void push(int distance, int velocity);