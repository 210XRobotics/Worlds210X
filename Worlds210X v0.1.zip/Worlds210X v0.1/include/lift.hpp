#include "main.h"

void setLift(bool pto);